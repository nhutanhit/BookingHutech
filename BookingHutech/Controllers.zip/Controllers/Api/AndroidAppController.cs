﻿using BookingHutech.Api_BHutech.DAO;
using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Helper;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Request.BookingCarRequest;
using BookingHutech.Api_BHutech.Models.Request.BookingCarResponse;
using BookingHutech.Api_BHutech.Models.Response;
using BookingHutech.Api_BHutech.Models.Response.BookingCarResponse;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Results;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace BookingHutech.Controllers.Api
{
    public class AndroidAppController : ApiController
    {
        static DataAccess a = new DataAccess();
        static SqlConnection con = new SqlConnection(a.ConnectionString());
        static SqlCommand cmd;
        static SqlDataAdapter adap;

        static DataAccess db = new DataAccess();
        Helper helper = new Helper();
        DataEntity dataEntity = new DataEntity();


        // Get ds xe
        [System.Web.Http.HttpGet]
        public ApiResponse GetCarInfo()
        {
            List<AppCarInfo> listCar;
            AppCarInfo pr;
            listCar = new List<AppCarInfo>();
            con.Close();
            con.Open();
            cmd = new SqlCommand("uspGetCarInfo", con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                pr = new AppCarInfo();
                pr.Car_ID = Int32.Parse(reader["Car_ID"].ToString());
                pr.CarNumber = reader["CarNumber"].ToString(); 
                pr.CarName = reader["CarName"].ToString();
                pr.CarTypeName = reader["CarTypeName"].ToString(); 
                pr.CarImage = reader["CarImage"].ToString();
                listCar.Add(pr);
            }
            con.Close();

            return ApiResponse.Success(listCar); 
        }
        // Add profile 
        [System.Web.Http.HttpPost]
        public ApiResponse AddNewProfileCar(ProfileCarRequestModel request ) {

            try
            {
                string ProfileID = helper.CreateID();
                string CreatDayTime = helper.ToDayDateTime();
                //uspAddProfileCar { 0},{ 1},{ 2},{ 3},{ 4},{ 5},{ 6},{ 7},{ 8},{ 9},{ 10},{ 11},{ 12},{ 13},{ 14},{ 15},{ 16},{ 17},{ 18},{ 19}
                if (dataEntity.checkDataNull(request.DeputyDelegation))
                {
                    request.DeputyDelegation = "NULL";
                }
                if (dataEntity.checkDataNull(request.EmailDeputyDelegation))
                {
                    request.EmailDeputyDelegation = "NULL";
                }   
                if (dataEntity.checkDataNull(request.NumberPhoneDeputyDelegation))
                {
                    request.NumberPhoneDeputyDelegation = "NULL";
                }
                 
                string stringSqluspAddProfileCar = "uspAddProfileCar '" + ProfileID + "' ,'" + request.Account_ID + "' ,'" + request.UnitRequest + "', '" + request.Reason + "'," +
                    "'" + request.Leader + "','" + request.EmailLeader + "','" + request.NumberPhoneLeader + "',  '" + request.DeputyDelegation + "',  '" + request.EmailDeputyDelegation + "', " +
                    "'" + request.NumberPhoneDeputyDelegation + "', '" + request.DateTimeFrom + "', '" + request.DateTimeTo + "', '" + request.NumberPeople + "'," +
                    "'" + request.RouteTo + "', '" + request.DistanceTo + "', '" + request.RouteBack + "', '" + request.DistanceBack + "','" + 1 + "', '" + CreatDayTime + "', '" + request.CarTypeID + "'  ";

                db.ThucThiCL(stringSqluspAddProfileCar);

                return ApiResponse.Success();


            }
            catch (Exception ex)
            {
                con.Close();
                LogWriter.WriteException(ex);
                return ApiResponse.Error(107); //Hệ thống không thể kết nối đến Server!!
            }
        }

        // 1. Account_ID
        // 2. UnitRequest
        // 3. Reason
        // 4. Leader
        // 5. EmailLeader
        // 6. NumberPhoneLeader
        // 10. DateTimeFrom  // format 2018-11-10 17:30:00.000
        // 11. DateTimeTo  // 2018-11-10 17:30:00.000
        // 12. NumberPeople
        // 13. RouteTo
        // 14. DistanceTo
        // 15. RouteBack
        // 16. DistanceBack
        // 16. CarTypeID 


    }
}