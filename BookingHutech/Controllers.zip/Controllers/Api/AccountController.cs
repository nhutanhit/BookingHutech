﻿using BookingHutech.Api_BHutech.DAO;  
using BookingHutech.Api_BHutech.DAO.AccountDAO;  
using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Helper;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Request;
using BookingHutech.Api_BHutech.Models.Request.BookingCarRequest;
using BookingHutech.Api_BHutech.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace BookingHutech.Controllers.Api.Bookinghutech
{
    public class AccountController : ApiController
    {
        /// <summary>
        /// Lớp này sẽ gọi Account, kết nối với sql trả về giá trị 
        /// </summary>
        AccountDAO dao = new AccountDAO();
        Helper hp = new Helper();
        /// <summary>
        ///   Login
        /// </summary>
        /// <param name="request">AccountLoginRequestModel</param>
        /// <returns>Return Data + Return Code</returns>
        [HttpPost]
        public ApiResponse Login([FromBody] AccountLoginRequestModel request)
        {
            try
            {
                LogWriter.WriteException("Account\t:" + request.UserName + "\tLogin");
                var result = dao.AccountLogin(request);
                // Kiểm tra để trả về cho người dùng.  
                return ApiResponse.Success(result);
            }
            catch (BHutechException ex)
            {
                LogWriter.WriteException(ex);
                return ApiResponse.Error(106);  // Có lỗi trong quá trình xử lý
                // ghi log nhá. 
            }
        }

        /// <author>anh.tran</author>
        /// <summary>
        /// Logout
        /// </summary>
        /// <param name="request">AccountLogoutRequestModel</param>
        /// <returns>ApiResponse</returns>
        [HttpPut]
        public ApiResponse Logout(AccountLogoutRequestModel request)
        {
            try
            { 
                var result = dao.AccountLogout(request.Account_ID);
                return ApiResponse.Success();   //Vui lòng đăng nhập để tiếp tục sử dụng!
            }
            catch (BHutechException ex)
            {
                LogWriter.WriteException(ex);
                return ApiResponse.Error(106);  // Có lỗi trong quá trình xử lý
                // ghi log nhá. 
            }
        }


       














    }
}