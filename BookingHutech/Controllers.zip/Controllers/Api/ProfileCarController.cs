﻿using BookingHutech.Api_BHutech.DAO;
using BookingHutech.Api_BHutech.DAO.Cars;
using BookingHutech.Api_BHutech.DAO.AccountDAO;
using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Helper;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Request;
using BookingHutech.Api_BHutech.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Profile;
using System.Web.Script.Serialization;
using BookingHutech.Api_BHutech.DAO.Profiles;
using BookingHutech.Api_BHutech.Models.Request.BookingCarRequest;
using BookingHutech.Api_BHutech.DAO.BookingManager.BookingCarManager;

namespace BookingHutech.Controllers.Api
{
    public class ProfileCarController : ApiController
    {

        // Lớp này sẽ như là core. Xử lý  trả data và mã lỗi về cho web.  
        ProfileResponseModel model = new ProfileResponseModel();
        AccountLoginResponseModel res = new AccountLoginResponseModel();
        Helper helper = new Helper();
        CheckPermissions checkPermiss = new CheckPermissions();
        DataEntity dataEntity = new DataEntity();
        

        Profiles  profile = new  Profiles(); 
        /// <summary>
        ///   getListProfileCheck
        /// </summary>
        /// <param name="request"></param>
        /// <returns>List Car and List Profile</returns>
        [HttpPost]
        public ApiResponse getListProfileCheck(SearchProfileRepuestModel request)
        {

            try
            {
                var result = CheckPermissions(501); //Button - Tìm Kiếm Xe, Hội Trường Để Cấp Phát
                if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {
                    //    (int)BHutechExceptionType.ACCOUNTDELETE
                    //          ACCOUNTDELETE = 102,
                    //NotSession = 114,
                    //ISCHANGEPASSWORD = 135,
                    //NOTPERMISSION = 150,

                    switch (result.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();  
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            // Kiểm tra để trả về cho người dùng.  
                            var profileInfo = profile.getListProfileCheck(request);
                            return ApiResponse.Success(profileInfo);
                            
                    } 

                }
                else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                else  // Ok đi tiếp. 
                {
                    
                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }

        }
        /// <summary>
        ///   AddProfile
        /// </summary>
        /// <param name="request"></param>
        /// <returns>return code</returns>
        [HttpPut]
        public ApiResponse AddProfile(ProfileCarRequestModel request)
        {

            try
            {
                var result = CheckPermissions(502);
                if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                { 
                    switch (result.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            return ApiResponse.Success(profile.AddProfileCar(request, (int)result.Data));
                            // Kiểm tra để trả về cho người dùng.  
                            //var profileInfo = ;


                    }

                }
                else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                else  // Ok đi tiếp. 
                {

                }
                return ApiResponse.Error();
            }
            catch (Exception ex)
            {
                return ApiResponse.Error();
                throw;
            }

            //var profileInfo = profile.AddProfileCar(request);
            //return ApiResponse.Success(profileInfo);
            // return null; 
        }


        /// <summary>
        ///   Lấy danh sách đơn cấp phát của account id
        /// </summary>
        /// <param name="request"></param>
        /// <returns>List Car and List Profile</returns>
        [HttpGet]
        public ApiResponse GetProfileCarByAccountID()
        {

            try
            {
                var result = CheckPermissions(503); // Màng hình - Xem các đơn cấp phát 
                if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {

                    switch (result.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            // Kiểm tra để trả về cho người dùng.   
                            return ApiResponse.Success(profile.GetListProfileByAccountID((int)result.Data));

                    }

                }
                else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }

        }








        //CheckPermissions
        public ApiResponse CheckPermissions(int RuleCode)
        {
            try
            {
                AccountLoginResponseModel res = new AccountLoginResponseModel();
                JavaScriptSerializer js = new JavaScriptSerializer();
                CookieHeaderValue CookieAccountInfo = Request.Headers.GetCookies("AccountInfoCheck").FirstOrDefault();
                if (CookieAccountInfo == null)
                { 
                    return ApiResponse.Success(114); // Mất Sess
                }
                string stringAccountInfo = CookieAccountInfo.Cookies[0].Value;
                string stringRoleCode = CookieAccountInfo.Cookies[1].Value;
                AccountInfo AccountInfo = js.Deserialize<AccountInfo>(stringAccountInfo);
                //getRoleCode[] RoleCode = js.Deserialize<getRoleCode[]>(stringRoleCode);  
                int CheckAccunt = checkPermiss.CheckAccount(RuleCode, AccountInfo);
                if (CheckAccunt == (int)BHutechExceptionType.SUCCESS)
                {
                    if (AccountInfo.Account_ID == 0)
                    {
                        return ApiResponse.Error();
                    }
                    else {
                        return ApiResponse.Success(AccountInfo.Account_ID); // OK đi tiếp
                    } 
                }
                else if (CheckAccunt == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();  // Có lỗi
                }
                else
                {
                    return ApiResponse.Success(CheckAccunt);  // Thành công, -> Có lỗi {Account, Quyền,vvv}
                }

            }
            catch (Exception)
            {
                return ApiResponse.Error();
                throw;
            }

        }

    }
}