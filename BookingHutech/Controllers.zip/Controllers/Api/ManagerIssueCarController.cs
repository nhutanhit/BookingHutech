﻿using BookingHutech.Api_BHutech.DAO.Profiles;
using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Request.BookingCarRequest;
using BookingHutech.Api_BHutech.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace BookingHutech.Controllers.Api
{
    public class ManagerIssueCarController: ApiController
    {
        CheckPermissions checkPermiss = new CheckPermissions();
        Profiles profile = new Profiles();
        /// <summary>
        ///   Tìm kiếm đơn cấp phát xe. 
        /// </summary>
        /// <param name="request"></param>
        /// <returns>List Car and List Profile</returns>
        [HttpPost]
        public ApiResponse ManagerIssueCarByProfile(SearchProfileRepuestModel request)
        {

            try
            {
                var result = CheckPermissions(501); // Cấp xe.  
                if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {

                    switch (result.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            // Kiểm tra để trả về cho người dùng.   
                            return ApiResponse.Success(profile.ManagerIssueCarByProfile(request));
                    }

                }
                else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }

        }



        //CheckPermissions & AccountLogin
        public ApiResponse CheckPermissions(int RuleCode)
        {
            try
            {
                AccountLoginResponseModel res = new AccountLoginResponseModel();
                JavaScriptSerializer js = new JavaScriptSerializer();
                CookieHeaderValue CookieAccountInfo = Request.Headers.GetCookies("AccountInfoCheck").FirstOrDefault();
                if (CookieAccountInfo == null)
                {
                    return ApiResponse.Success(114); // Mất Sess
                }
                string stringAccountInfo = CookieAccountInfo.Cookies[0].Value;
                string stringRoleCode = CookieAccountInfo.Cookies[1].Value;
                AccountInfo AccountInfo = js.Deserialize<AccountInfo>(stringAccountInfo);
                //getRoleCode[] RoleCode = js.Deserialize<getRoleCode[]>(stringRoleCode);  
                int CheckAccunt = checkPermiss.CheckAccount(RuleCode, AccountInfo);
                if (CheckAccunt == (int)BHutechExceptionType.SUCCESS)
                {
                    if (AccountInfo.Account_ID == 0)
                    {
                        return ApiResponse.Error();
                    }
                    else
                    {
                        return ApiResponse.Success(AccountInfo.UserName); // OK đi tiếp
                    }
                }
                else if (CheckAccunt == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();  // Có lỗi
                }
                else
                {
                    return ApiResponse.Success(CheckAccunt);  // Thành công, -> Có lỗi {Account, Quyền,vvv}
                }

            }
            catch (Exception)
            {
                return ApiResponse.Error();
            }

        }
    }
}