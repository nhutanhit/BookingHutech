﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;
using BookingHutech.Api_BHutech.DAO.BookingMeetingHallDAO;
using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Request.BookingMeetingHallRequest;
using BookingHutech.Api_BHutech.Models.Response;

namespace BookingHutech.Controllers.Api
{
    /// <summary>
    /// Lớp này chưa các hàm gọi đến các hàm ở lớp DAO Trả về kết quả cho người  dùng-> 
    /// </summary>
    public class MeetingHallController : ApiController
    {
        ///Lớp kết nối với DAO
        MeetingHallDAO meetingHallDAO = new MeetingHallDAO();
        /// Lớp kết nối với lớp kiểm tra quyền
        CheckPermissions checkPermiss = new CheckPermissions();

        /// <author>anh.tran</author>
        /// <summary>
        ///  getListProfileCheck
        /// </summary>
        /// <param name="request"></param>
        /// <returns>List Car and List Profile</returns>
        [HttpGet]
        public ApiResponse GetListMeetingHall()
        {

            try
            {
                var result = CheckPermissions(116); // 116 Xem danh sách  hội trường. 
                if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {
                    switch (result.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            var messtingHallInfo = meetingHallDAO.GetMeetingHallsInfo();
                            return ApiResponse.Success(messtingHallInfo);

                    }

                }
                else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                else  // Ok đi tiếp. 
                {

                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }

        }

        /// <author>anh.tran</author>
        /// <summary>
        ///  AddProfileMeetingHall
        /// </summary>
        /// <param name="request"></param>
        /// <returns>ApiResponse</returns>
        [HttpPost]
        public ApiResponse AddProfileMeetingHall(AddProfileMeetingHallRequestModel request)
        {

            try
            {
                var result = CheckPermissions(502); // 502 Đặt  hội trường. 
                if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {
                    switch (result.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            var messtingHallInfo = meetingHallDAO.AddProfileCar(request, (int)result.Data);
                            return ApiResponse.Success(messtingHallInfo);

                    }

                }
                else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                else  // Ok đi tiếp. 
                {

                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }

        }

        /// <author>anh.tran</author>
        /// <summary>
        ///  GetProfileMeetingHall
        /// </summary>
        /// <param name="request"></param>
        /// <returns>ApiResponse</returns>
        [HttpPut]
        public ApiResponse GetProfileMeetingHall(GetProfileMeetingHallRequestModel request)
        {

            try
            {
                var result = CheckPermissions(503); // 503 Xem các đơn đăng ký cấp phát Xe, Hội Trường. 
                if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {
                    switch (result.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            var messtingHallInfo = meetingHallDAO.GetProfileMeetingHalls(request);
                            return ApiResponse.Success(messtingHallInfo);

                    }

                }
                else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                else  // Ok đi tiếp. 
                {

                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }

        }

         
        /// <author>anh.tran</author>
        /// <summary>
        /// CheckPermissions
        /// </summary>
        /// <param name="RuleCode">Mã quyền</param>
        /// <returns>ApiResponse and AccountID</returns>
        public ApiResponse CheckPermissions(int RuleCode)
        {
            try
            {
                AccountLoginResponseModel res = new AccountLoginResponseModel();
                JavaScriptSerializer js = new JavaScriptSerializer();
                CookieHeaderValue CookieAccountInfo = Request.Headers.GetCookies("AccountInfoCheck").FirstOrDefault();
                if (CookieAccountInfo == null)
                {
                    return ApiResponse.Success(114); // Mất Sess
                }
                string stringAccountInfo = CookieAccountInfo.Cookies[0].Value;
                string stringRoleCode = CookieAccountInfo.Cookies[1].Value;
                AccountInfo AccountInfo = js.Deserialize<AccountInfo>(stringAccountInfo);
                int CheckAccunt = checkPermiss.CheckAccount(RuleCode, AccountInfo);
                if (CheckAccunt == (int)BHutechExceptionType.SUCCESS)
                {
                    if (AccountInfo.Account_ID == 0)
                    {
                        return ApiResponse.Error();
                    }
                    else
                    {
                        return ApiResponse.Success(AccountInfo.Account_ID);
                    }
                }
                else if (CheckAccunt == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                else
                {
                    return ApiResponse.Success(CheckAccunt);  // Thành công, -> Có lỗi {Account, Quyền,vvv}
                }

            }
            catch (Exception ex)
            {
                // Write log, check permission error
                LogWriter.WriteException(ex);
                return ApiResponse.Error();
                throw;
            }

        }
    }
}