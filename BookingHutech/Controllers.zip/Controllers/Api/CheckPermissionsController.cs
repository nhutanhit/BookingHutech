﻿using BookingHutech.Api_BHutech.DAO.AccountDAO;
using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Request;
using BookingHutech.Api_BHutech.Models.Request.BookingCarRequest;
using BookingHutech.Api_BHutech.Models.Response;
using BookingHutech.Api_BHutech.Models.Response.BookingCarResponse;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace BookingHutech.Controllers.Api
{
    public class CheckPermissionsController : ApiController
    {
        CheckPermissions checkPermiss = new CheckPermissions();
        AccountDAO dao = new AccountDAO();
        [HttpPost]
        public ApiResponse CheckAccont(RuleCodeRequestModel Role)
        {
            try
            {
                var CheckAccount = GetCookies(Role.RuleCode);
                if (CheckAccount.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {
                    //    (int)BHutechExceptionType.ACCOUNTDELETE
                    //          ACCOUNTDELETE = 102,
                    //NotSession = 114,
                    //ISCHANGEPASSWORD = 135,
                    //NOTPERMISSION = 150,

                    switch (CheckAccount.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            return ApiResponse.Success(); 
                    }

                }
                else if (CheckAccount.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                else  // Ok đi tiếp. 
                {

                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }
        }
         
        [HttpGet]
        public ApiResponse ManagerGetRoleMaster()
        {
            try
            {
                var CheckAccount = GetCookies(907);
                if (CheckAccount.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {
                    //    (int)BHutechExceptionType.ACCOUNTDELETE
                    //          ACCOUNTDELETE = 102,
                    //NotSession = 114,
                    //ISCHANGEPASSWORD = 135,
                    //NOTPERMISSION = 150,

                    switch (CheckAccount.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            return ApiResponse.Success(dao.ManagerGetRoleMasterInfo());
                    }

                }
                else if (CheckAccount.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                else  // Ok đi tiếp. 
                {

                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }
        }

      


        //CheckPermissions
        public ApiResponse GetCookies(int RuleCode)
        {
            try
            {
                AccountLoginResponseModel res = new AccountLoginResponseModel();
                JavaScriptSerializer js = new JavaScriptSerializer();
                CookieHeaderValue CookieAccountInfo = Request.Headers.GetCookies("AccountInfoCheck").FirstOrDefault();
                if (CookieAccountInfo == null)
                {
                    return ApiResponse.Success(114); // Mất Sess
                }
                string stringAccountInfo = CookieAccountInfo.Cookies[0].Value;
                string stringRoleCode = CookieAccountInfo.Cookies[1].Value;
                AccountInfo AccountInfo = js.Deserialize<AccountInfo>(stringAccountInfo);
                //getRoleCode[] RoleCode = js.Deserialize<getRoleCode[]>(stringRoleCode);  
                int CheckAccunt = checkPermiss.CheckAccount(RuleCode, AccountInfo);
                if (CheckAccunt == (int)BHutechExceptionType.SUCCESS)
                {
                    return ApiResponse.Success(AccountInfo.Account_ID); // OK đi tiếp
                }
                else if (CheckAccunt == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();  // Có lỗi
                }
                else
                {
                    return ApiResponse.Success(CheckAccunt);  // Thành công, -> Có lỗi {Account, Quyền,vvv}
                }

            }
            catch (Exception)
            {
                return ApiResponse.Error();
                throw;
            }

        }
    }
}