﻿using BookingHutech.Api_BHutech.DAO;  
using BookingHutech.Api_BHutech.DAO.AccountDAO;  
using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Helper;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Request;
using BookingHutech.Api_BHutech.Models.Request.BookingCarRequest;
using BookingHutech.Api_BHutech.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace BookingHutech.Controllers.Api.Bookinghutech
{
    public class AccountManagerController : ApiController
    {
        /// <summary>
        /// Lớp này quản lý việc : Lấy danh sách tai khoản, 
        /// </summary>
        AccountDAO dao = new AccountDAO();
        Helper hp = new Helper();
        CheckPermissions checkPermiss = new CheckPermissions();

        /// <author>anh.tran</author>
        /// <summary>
        /// ManagerSearchAccount
        /// </summary>
        /// <param name="request">Get List Account</param>
        /// <returns>ApiResponse</returns>
        [HttpPut]
        public ApiResponse ManagerSearchAccount(ManagerSearchAccountRequestModel request)
        {
            try
            {


                var result = CheckPermissions(904); // Màng hình - Xem các đơn cấp phát 
                if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {

                    switch (result.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            // Kiểm tra để trả về cho người dùng.   
                            return ApiResponse.Success(dao.ManagerSearchGetListAccount(request ));

                    }

                }
                else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <author>anh.tran</author>
        /// <summary>
        /// ManagerShowDetailAccount
        /// </summary>
        /// <param name="request">Get Account Info and Role code</param>
        /// <returns>ApiResponse</returns>
        [HttpPost]
        public ApiResponse ManagerShowDetailAccount(ManagerSearchAccountRequestModel request)
        {
            try
            {
                  
                var result = CheckPermissions(905);   // Manager xem chi tiết account
                if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                {

                    switch (result.Data)
                    {
                        case 102:
                            return ApiResponse.AccountDelete();
                        case 114:
                            return ApiResponse.NotSession();
                        case 135:
                            return ApiResponse.IsChangePassword();
                        case 150:
                            return ApiResponse.NotPermission();
                        default:
                            // Kiểm tra để trả về cho người dùng.   
                            return ApiResponse.Success(dao.GetDetailAccountByAccountID(request));

                    }

                }
                else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();
                }
                return ApiResponse.Error();
            }
            catch (Exception)
            {

                throw;
            }
        }


        //CheckPermissions
        public ApiResponse CheckPermissions(int RuleCode)
        {
            try
            {
                AccountLoginResponseModel res = new AccountLoginResponseModel();
                JavaScriptSerializer js = new JavaScriptSerializer();
                CookieHeaderValue CookieAccountInfo = Request.Headers.GetCookies("AccountInfoCheck").FirstOrDefault();
                if (CookieAccountInfo == null)
                {
                    return ApiResponse.Success(114); // Mất Sess
                }
                string stringAccountInfo = CookieAccountInfo.Cookies[0].Value;
                string stringRoleCode = CookieAccountInfo.Cookies[1].Value;
                AccountInfo AccountInfo = js.Deserialize<AccountInfo>(stringAccountInfo);
                //getRoleCode[] RoleCode = js.Deserialize<getRoleCode[]>(stringRoleCode);  
                int CheckAccunt = checkPermiss.CheckAccount(RuleCode, AccountInfo);
                if (CheckAccunt == (int)BHutechExceptionType.SUCCESS)
                {
                    if (AccountInfo.Account_ID == 0)
                    {
                        return ApiResponse.Error();
                    }
                    else
                    {
                        return ApiResponse.Success(AccountInfo.Account_ID); // OK đi tiếp
                    }
                }
                else if (CheckAccunt == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();  // Có lỗi
                }
                else
                {
                    return ApiResponse.Success(CheckAccunt);  // Thành công, -> Có lỗi {Account, Quyền,vvv}
                }

            }
            catch (Exception)
            {
                return ApiResponse.Error();
                throw;
            }

        }


    }
}