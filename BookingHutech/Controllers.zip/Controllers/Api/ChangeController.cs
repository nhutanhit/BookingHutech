﻿using BookingHutech.Api_BHutech.DAO;
using BookingHutech.Api_BHutech.DAO.AccountDAO;
using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Request;
using BookingHutech.Api_BHutech.Models.Request.BookingCarRequest;
using BookingHutech.Api_BHutech.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace BookingHutech.Controllers.Api.Account
{
    public class ChangeController : ApiController
    {
        AccountDAO dao = new AccountDAO();
        /// <author>anh.tran</author>
        /// <summary>
        /// ChangePassword
        /// </summary>
        /// <param name="request">ChangePasswordRequestModel</param>
        /// <returns>ApiResponse</returns>
        [HttpPost]
        public ApiResponse ChangePassword([FromBody] ChangePasswordRequestModel request)
        {

            try
            {
                // Phải có: độ dài ký tự 6-20, chữ hoa, chữ thường, số. 
                // Không được có: khoản trắng, chữ có dấu. 
                // Có thể cho phép có or không có cũng được: Ký tự đặc biệt, "{[.,/\|+=*&^%$#@!~`"
                if (DataEntity.checkPassWord(request.Password) == false)
                {
                    return ApiResponse.ErrorInputDataEntity(113);
                }
                // check Confirm PassWor dotherl 
                else
                {
                    var response = dao.CheckPassword(request);
                    return ApiResponse.Success(response);
                } 
            }
            catch (BHutechException ex)
            {
                //LogWriter.WriteException(ex);
                return ApiResponse.Error((int)ex.type);
            }
            catch (Exception ex)
            {
                // LogWriter.WriteException(ex);
                return ApiResponse.Error();
            }
        }
    }
}