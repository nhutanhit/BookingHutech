﻿using BookingHutech.Api_BHutech.DAO;
using BookingHutech.Api_BHutech.DAO.Cars;
using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Helper;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace BookingHutech.Controllers.Api.Bookinghutech
{
    public class CarController : ApiController
    {
        // Lớp này sẽ như là core. Xử lý  trả data và mã lỗi về cho web. 
        Cars bookingCar = new Cars();
        Helper helpe = new Helper();
        CheckPermissionsController Permiss = new CheckPermissionsController();
        /// <summary>
        ///   GetListCar
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return Data + Return Code</returns>
        [HttpGet]
        public ApiResponse GetListCar()
        {
            try
            {
                //LogWriter.WriteException("Account\t:\tGet danh sách xe");
                //// gọi hàm kiểm tra login trước 

                
                var result = bookingCar.GetCarInfo();
                // Kiểm tra để trả về cho người dùng.  
                return ApiResponse.Success(result);
            }
            catch (BHutechException ex)
            {
                LogWriter.WriteException(ex);
                return ApiResponse.Error(106);  // Có lỗi trong quá trình xử lý
                // ghi log nhá. 
            }
        }

      

    }
}