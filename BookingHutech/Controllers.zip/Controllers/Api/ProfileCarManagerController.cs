﻿using BookingHutech.Api_BHutech.Lib;
using BookingHutech.Api_BHutech.Lib.Helper;
using BookingHutech.Api_BHutech.Lib.Utils;
using BookingHutech.Api_BHutech.Models.Request;
using BookingHutech.Api_BHutech.Models.Request.BookingCarRequest;
using BookingHutech.Api_BHutech.DAO.BookingManager.BookingCarManager;
using BookingHutech.Api_BHutech.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;
using BookingHutech.Api_BHutech.Models.Response.BookingCarResponse;

namespace BookingHutech.Controllers.Api
{
    public class ProfileCarManagerController : ApiController
    {

        ProfileResponseModel model = new ProfileResponseModel();
        AccountLoginResponseModel res = new AccountLoginResponseModel();
        Helper helper = new Helper();
        CheckPermissions checkPermiss = new CheckPermissions();
        DataEntity dataEntity = new DataEntity();

        ProfileManager profileManager = new ProfileManager();
        
        /// <summary>
        ///   Tìm kiếm đơn cấp phát xe. 
        /// </summary>
        /// <param name="request"></param>
        /// <returns>List Car and List Profile</returns>
        [HttpPost]
        public ApiResponse ManagerSearchProfileCar(SearchProfileRepuestModel request)
        {

            try
            {
                // Chờ ban giám hiệu duyệt .Không duyệt
                if (request.Profile_Status == 3 || request.Profile_Status == 6 || request.Profile_Status == 4)
                {
                    return ApiResponse.Success(profileManager.SearchProfileCarByProfileID(request));
                }
               else if (request.Profile_Status == 4 || request.Profile_Status == 6)
                {
                    var result = CheckPermissions(117);
                    if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                    {


                        switch (result.Data)
                        {
                            case 102:
                                return ApiResponse.AccountDelete();
                            case 114:
                                return ApiResponse.NotSession();
                            case 135:
                                return ApiResponse.IsChangePassword();
                            case 150:
                                return ApiResponse.NotPermission();
                            default:
                                // Kiểm tra để trả về cho người dùng.   
                                return ApiResponse.Success(profileManager.SearchProfileCarByProfileID(request));

                        }

                    }
                    else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                    {
                        return ApiResponse.Error();
                    }
                    else  // Ok đi tiếp. 
                    {

                    }
                    return ApiResponse.Error();
                }
                else {
                    var result = CheckPermissions(901); //901: Button - Tìm Kiếm Đơn Cấp Phát Xe - Cấp Phòng Quản Trị
                    if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                    {


                        switch (result.Data)
                        {
                            case 102:
                                return ApiResponse.AccountDelete();
                            case 114:
                                return ApiResponse.NotSession();
                            case 135:
                                return ApiResponse.IsChangePassword();
                            case 150:
                                return ApiResponse.NotPermission();
                            default:
                                // Kiểm tra để trả về cho người dùng.   
                                return ApiResponse.Success(profileManager.SearchProfileCarByProfileID(request));

                        }

                    }
                    else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                    {
                        return ApiResponse.Error();
                    }
                    else  // Ok đi tiếp. 
                    {

                    }
                    return ApiResponse.Error();
                }
               
                
            }
            catch (Exception ex)
            {
                LogWriter.WriteException(ex);
                return ApiResponse.Error(107); //Hệ thống có lỗi trong quá trình xử lý!
            }

        }

         
        /// <summary>
        ///   Tìm kiếm đơn cấp phát xe. 
        /// </summary>
        /// <param name="request"></param>
        /// <returns>List Car and List Profile</returns>
        [HttpPut]
        public ApiResponse ManagerUpdateStatusProfileCar(ManagerUpdateStatusProfileCarRequestModel request)
        {
                    
            try
            {
                if (request.Profile_Status == 4)
                {
                    var result = CheckPermissions(117); // Option - Ban Giám Hiệu - (Tìm Kiếm, Duyệt, Không Duyệt)  
                    if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                    {
                            
                        switch (result.Data)
                        {
                            case 102:
                                return ApiResponse.AccountDelete();
                            case 114:
                                return ApiResponse.NotSession();
                            case 135:
                                return ApiResponse.IsChangePassword();
                            case 150:
                                return ApiResponse.NotPermission();
                            default:
                                // Kiểm tra để trả về cho người dùng.   
                                return ApiResponse.Success(profileManager.UpdateStatusProfileCar(request, (string)result.Data));

                        }

                    }
                    else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                    {
                        return ApiResponse.Error();
                    }
                    return ApiResponse.Error();
                }
                else {
                    var result = CheckPermissions(903); // Button - Cập Nhật Trang Thái  Đơn Cấp Phát Xe .  
                    if (result.ReturnCode == (int)BHutechExceptionType.SUCCESS)
                    {

                        switch (result.Data)
                        {
                            case 102:
                                return ApiResponse.AccountDelete();
                            case 114:
                                return ApiResponse.NotSession();
                            case 135:
                                return ApiResponse.IsChangePassword();
                            case 150:
                                return ApiResponse.NotPermission();
                            default:
                                // Kiểm tra để trả về cho người dùng.   
                                return ApiResponse.Success(profileManager.UpdateStatusProfileCar(request, (string)result.Data));

                        }

                    }
                    else if (result.ReturnCode == (int)BHutechExceptionType.ERROR)
                    {
                        return ApiResponse.Error();
                    }
                    return ApiResponse.Error();
                }
                 
            }
            catch (Exception)
            {

                throw;
            }

        }
         
       

        //CheckPermissions & AccountLogin
        public ApiResponse CheckPermissions(int RuleCode)
        {
            try
            {
                AccountLoginResponseModel res = new AccountLoginResponseModel();
                JavaScriptSerializer js = new JavaScriptSerializer();
                CookieHeaderValue CookieAccountInfo = Request.Headers.GetCookies("AccountInfoCheck").FirstOrDefault();
                if (CookieAccountInfo == null)
                {
                    return ApiResponse.Success(114); // Mất Sess
                }
                string stringAccountInfo = CookieAccountInfo.Cookies[0].Value;
                string stringRoleCode = CookieAccountInfo.Cookies[1].Value;
                AccountInfo AccountInfo = js.Deserialize<AccountInfo>(stringAccountInfo);
                //getRoleCode[] RoleCode = js.Deserialize<getRoleCode[]>(stringRoleCode);  
                int CheckAccunt = checkPermiss.CheckAccount(RuleCode, AccountInfo);
                if (CheckAccunt == (int)BHutechExceptionType.SUCCESS)
                {
                    if (AccountInfo.Account_ID == 0)
                    {
                        return ApiResponse.Error();
                    }
                    else
                    {
                        return ApiResponse.Success(AccountInfo.UserName); // OK đi tiếp
                    }
                }
                else if (CheckAccunt == (int)BHutechExceptionType.ERROR)
                {
                    return ApiResponse.Error();  // Có lỗi
                }
                else
                {
                    return ApiResponse.Success(CheckAccunt);  // Thành công, -> Có lỗi {Account, Quyền,vvv}
                }

            }
            catch (Exception)
            {
                return ApiResponse.Error(); 
            }

        }

    }
}